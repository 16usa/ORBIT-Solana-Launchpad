ORBIT Stage 25 - Privy session integration (phase 1)

From Replit Shell (workspace root):
  unzip -o orbit_stage25.zip -d /tmp/orbit_stage25
  python3 /tmp/orbit_stage25/install.py

Set VITE_PRIVY_APP_ID in Replit Secrets for frontend environment.
This phase adds Privy email/wallet LOGIN, keeping existing Phantom adapter for on-chain signing.
It does NOT yet support signing trades with a Privy embedded wallet; never assume it does.
No restarts, Git pushes or republishing performed.
