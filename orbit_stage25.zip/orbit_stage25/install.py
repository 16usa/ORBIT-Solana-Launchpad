from pathlib import Path
import os, subprocess, sys
root=Path('/home/runner/workspace/artifacts/orbit-launchpad/original/orbit-solana-launchpad')
if not root.exists():
 print('ERROR: ORBIT source directory not found');sys.exit(1)
src=root/'web/src'; app=src/'App.tsx'; button=src/'OrbitWalletButton.tsx'
for p in [app,button]:
 if not p.exists(): print('Missing',p);sys.exit(1)
apptext=app.read_text(); bt=button.read_text()
if 'ORBIT_STAGE25_PRIVY' in apptext:
 print('Stage 25 already installed; no changes.');sys.exit(0)
if "import WalletSetup from './WalletProvider';" not in apptext or 'return <WalletSetup rpc={config.rpc}>' not in apptext:
 print('Unexpected App.tsx layout; aborting without edits.');sys.exit(1)
if 'export default function OrbitWalletButton' not in bt:
 print('Unexpected wallet button layout; aborting.');sys.exit(1)
# Login is separate from transaction signer. Keep Phantom adapter unchanged.
(src/'PrivySession.tsx').write_text('''// ORBIT_STAGE25_PRIVY: login session only. Trading remains on the connected Solana wallet.\nimport React from 'react';\nimport { PrivyProvider, usePrivy } from '@privy-io/react-auth';\nconst appId = import.meta.env.VITE_PRIVY_APP_ID || '';\nexport function PrivyBoundary({children}:{children:React.ReactNode}) {\n  if (!appId) return <>{children}</>;\n  return <PrivyProvider appId={appId} config={{loginMethods:['email','wallet'], appearance:{theme:'dark'}}}>{children}</PrivyProvider>;\n}\nexport function PrivyLogin() {\n  const {ready,authenticated,login,logout,user}=usePrivy();\n  if(!ready) return <button type="button" disabled className="wallet-adapter-button">Loading…</button>;\n  if(authenticated) return <button type="button" className="wallet-adapter-button" title={user?.email?.address||'Privy account'} onClick={()=>void logout()}>Sign out</button>;\n  return <button type="button" className="wallet-adapter-button" onClick={login}>Sign in</button>;\n}\nexport function OptionalPrivyLogin(){return appId?<PrivyLogin/>:null;}\n''')
apptext=apptext.replace("import WalletSetup from './WalletProvider';", "import WalletSetup from './WalletProvider';\nimport {PrivyBoundary} from './PrivySession'; // ORBIT_STAGE25_PRIVY")
apptext=apptext.replace('return <WalletSetup rpc={config.rpc}><Shell config={config}/></WalletSetup>', 'return <PrivyBoundary><WalletSetup rpc={config.rpc}><Shell config={config}/></WalletSetup></PrivyBoundary>')
# If formatting changed, ensure replacement took effect before writing.
if '<PrivyBoundary><WalletSetup' not in apptext:
 print('App wrapping not matched; aborting.');(src/'PrivySession.tsx').unlink();sys.exit(1)
bt=bt.replace("import { WalletReadyState } from '@solana/wallet-adapter-base';", "import { WalletReadyState } from '@solana/wallet-adapter-base';\nimport {OptionalPrivyLogin} from './PrivySession';")
# Render auth entry alongside wallet in header, without overriding wallet signing.
apptext=apptext.replace('<OrbitWalletButton/></div></header>', '<OptionalPrivyLogin/><OrbitWalletButton/></div></header>')
apptext=apptext.replace("import {PrivyBoundary} from './PrivySession';", "import {PrivyBoundary,OptionalPrivyLogin} from './PrivySession';")
app.write_text(apptext)
# No need to change existing wallet button.
print('Stage25 source installed. Installing dependency (no process restart, no publish)...')
cmd=['pnpm','--filter','@workspace/orbit-launchpad','add','@privy-io/react-auth']
result=subprocess.run(cmd,cwd='/home/runner/workspace')
if result.returncode:print('Dependency install failed. Fix pnpm issue before testing.');sys.exit(result.returncode)
for name in ['typecheck','build']:
 result=subprocess.run(['pnpm','--filter','@workspace/orbit-launchpad','run',name],cwd='/home/runner/workspace')
 if result.returncode:print('FAILED:',name);sys.exit(result.returncode)
print('STAGE25 PASS. Configure VITE_PRIVY_APP_ID in Replit Secrets for the frontend build. Development restart manual. No publish performed.')
