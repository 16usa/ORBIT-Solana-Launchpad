import { defineConfig } from 'vite';
export default defineConfig({
  root: 'web',
  envDir: '..',
  publicDir: 'public',
  build: { outDir: '../dist', emptyOutDir: true, target: 'es2022' },
  define: { 'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'development') },
  server: { host: '0.0.0.0', port: 5173, proxy: { '/api': 'http://127.0.0.1:3000', '/media': 'http://127.0.0.1:3000', '/metadata': 'http://127.0.0.1:3000' } }
});
