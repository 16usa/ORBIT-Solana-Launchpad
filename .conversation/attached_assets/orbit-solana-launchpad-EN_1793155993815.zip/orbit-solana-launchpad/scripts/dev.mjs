import { spawn } from 'node:child_process';
try {process.loadEnvFile('.env')} catch(e){if(e.code!=='ENOENT')throw e}
const args = { stdio: 'inherit', env: process.env, shell: process.platform === 'win32' };
const api = spawn(process.execPath, ['server/app.mjs'], args);
const vite = spawn(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['exec','--','vite','--host','0.0.0.0'], args);
function stop(){api.kill(); vite.kill();}
process.once('SIGINT', stop);
process.once('SIGTERM', stop);
api.on('exit', (code) => { if(code && code !== 0){console.error('API stopped with', code); vite.kill();} });
vite.on('exit', (code) => { if(code && code !== 0){console.error('Vite stopped with', code); api.kill();} });
